package com.postgresql.indiegogo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IndiegogoApplication {

	public static void main(String[] args) {
		SpringApplication.run(IndiegogoApplication.class, args);
	}

}
